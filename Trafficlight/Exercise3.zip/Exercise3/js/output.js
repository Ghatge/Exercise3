$(document).ready(function () {
    let data=JSON.parse(localStorage["catData"]);
    $("#message").text(data.msg);
    $("#urgent").text(data.urgent?"Yes":"No");
});