$(document).ready(function(form){

    let msg = $("input[name=msg]:checked").val();
    let urgent = $("input[name=yes]").prop("checked");

    let catData = {msg, urgent};

    console.log(catData);

    localStorage["catData"] = JSON.stringify(catData);

});